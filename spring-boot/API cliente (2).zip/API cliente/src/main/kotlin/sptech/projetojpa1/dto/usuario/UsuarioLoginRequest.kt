package sptech.projetojpa1.dto.usuario

data class UsuarioLoginRequest(
    val email: String,
    val senha: String
)
