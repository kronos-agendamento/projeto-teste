package sptech.projetojpa1.dto.mensagem

class MensagemResponseDTO (
    val id:Int?,
    val descricao:String?
){
}