package sptech.projetojpa1.dto.especificacao

data class EspecificacaoReceitaMensalDTO(
    val mes: String,
    val receitaTotal: Double
)