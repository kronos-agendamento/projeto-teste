package sptech.projetojpa1.dto.usuario

data class UsuarioDTO(
    val codigo: Int,
    val nome: String,
    val instagram: String,
    val telefone: String,
    val cpf: String
)