package sptech.projetojpa1.dto.procedimento

data class ProcedimentoDTO(
    val idProcedimento: Int?,
    val tipo: String?,
    val descricao: String?
)
