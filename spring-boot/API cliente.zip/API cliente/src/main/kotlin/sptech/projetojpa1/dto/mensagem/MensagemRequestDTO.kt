package sptech.projetojpa1.dto.mensagem

class MensagemRequestDTO (
    var descricao:String?
) {
}