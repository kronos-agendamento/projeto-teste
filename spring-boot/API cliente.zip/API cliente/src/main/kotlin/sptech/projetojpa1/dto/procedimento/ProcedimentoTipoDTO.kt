package sptech.projetojpa1.dto.procedimento

data class ProcedimentoTipoDTO(
    var tipo: String
)
