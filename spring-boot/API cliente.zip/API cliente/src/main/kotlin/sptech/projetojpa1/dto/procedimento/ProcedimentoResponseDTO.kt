package sptech.projetojpa1.dto.procedimento

data class ProcedimentoResponseDTO(
    val idProcedimento: Int?,
    val tipo: String?,
    val descricao: String?
)
