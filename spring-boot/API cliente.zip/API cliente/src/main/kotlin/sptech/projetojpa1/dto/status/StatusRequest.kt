package sptech.projetojpa1.dto.status

data class StatusRequest(
    val nome: String,
    val cor: String?,
    val motivo: String?)
