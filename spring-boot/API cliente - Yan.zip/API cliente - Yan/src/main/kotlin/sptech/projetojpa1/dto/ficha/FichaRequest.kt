package sptech.projetojpa1.dto

import java.time.LocalDateTime

data class FichaRequest(
    val dataPreenchimento: LocalDateTime
)
