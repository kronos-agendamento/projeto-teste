package sptech.projetojpa1.dto.usuario

data class UsuarioFotoRequest (
    var foto: ByteArray
)