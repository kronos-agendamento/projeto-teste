package sptech.projetojpa1.dto.pergunta

data class PerguntaAttRequest(
    val descricao: String,
    val tipo: String
)
