package sptech.projetojpa1.dto.complemento

data class ComplementoResponseDTO(
    val codigo: Int,
    val complemento: String,
    val enderecoId: Int
)