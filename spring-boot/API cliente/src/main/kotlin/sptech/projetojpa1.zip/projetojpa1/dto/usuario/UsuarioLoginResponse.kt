package sptech.projetojpa1.dto.usuario

data class UsuarioLoginResponse(
    val mensagem: String,
    val nome: String,
    val email: String
)
